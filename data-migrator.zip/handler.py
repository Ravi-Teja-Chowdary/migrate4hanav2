"""
data-migrator (lift-and-shift) — MC/IDoc/LTMOM template generator only.

This Lambda used to do in-place loading. In lift-and-shift it has ONE job:
read the routed object spec, extract data from ECC via pyrfc, and emit
*tool-native templates* to S3:

    * MC lane     -> CSV/XLSX in the MC staging-table layout
    * IDoc lane   -> per-object IDoc XML files
    * LTMOM lane  -> mapping spec + sample CSV (manual SLT/LTMOM build)
    * BODS lane   -> dataflow-input CSV with column metadata

It does NOT push anything into S/4HANA. Push is done by the lane
orchestrators (migration-cockpit-orchestrator / idoc-orchestrator /
ltmom-orchestrator).
"""
from __future__ import annotations

import csv
import io
import json
import os
import re
import sys
import time

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "utils"))

import boto3  # noqa: E402

try:
    import sapnwrfc  # noqa: F401
except Exception:  # pragma: no cover
    pass

try:
    from logger import log_stage_event  # type: ignore
except Exception:  # pragma: no cover
    def log_stage_event(*a, **k):  # type: ignore
        pass

try:
    from unified_loader import UnifiedLoader, OBJECT_MECHANISM  # type: ignore
except Exception:  # pragma: no cover
    UnifiedLoader = None
    OBJECT_MECHANISM = {}

try:
    from currency_config import CurrencyConfigReconciler  # type: ignore
except Exception:  # pragma: no cover
    CurrencyConfigReconciler = None

try:
    from reconciler import Reconciler  # type: ignore
except Exception:  # pragma: no cover
    Reconciler = None

try:
    from key_map import KeyMap, PersistentKeyMap  # type: ignore
except Exception:  # pragma: no cover
    KeyMap = None
    PersistentKeyMap = None

try:
    import compliance  # type: ignore
except Exception:  # pragma: no cover
    compliance = None

try:
    import config_discovery  # type: ignore
except Exception:  # pragma: no cover
    config_discovery = None

S3 = boto3.client("s3")
SECRETS = boto3.client("secretsmanager")
STAGING_BUCKET = os.environ.get("S3_STAGING_BUCKET", "migrate4hanav2-staging-dev")

# Conservative per-invoke caps; production batching happens upstream.
MAX_ROWS_PER_TEMPLATE = int(os.environ.get("MAX_ROWS_PER_TEMPLATE", "50000"))

# Actually post extracted data into S/4 (via idoc_loader) when M4H_LOAD_TO_S4=1.
LOAD_TO_S4 = os.environ.get("M4H_LOAD_TO_S4", "0") == "1"
LOAD_MAX_ROWS = int(os.environ.get("M4H_LOAD_MAX_ROWS", "5"))
OWN_LOGICAL_SYSTEM = os.environ.get("M4H_TARGET_LOGSYS", "S4HCLNT100")
IDOC_SENDER = os.environ.get("M4H_IDOC_SENDER", "M4HSENDER")


def _ecc(secret_id: str):
    sec = json.loads(SECRETS.get_secret_value(SecretId=secret_id)["SecretString"])
    from pyrfc import Connection
    # Base connection kwargs from the secret. Optional gwhost/gwserv/saprouter
    # allow connection through a TCP forwarder (e.g. ngrok) where the published
    # port differs from the SAP-derived sapgw<NN> port.
    kwargs = {
        "ashost": sec["ashost"],
        "sysnr":  sec.get("sysnr", "00"),
        "client": sec["client"],
        "user":   sec["user"],
        "passwd": sec.get("passwd") or sec.get("password"),
        "lang":   sec.get("lang", "EN"),
    }
    for opt in ("gwhost", "gwserv", "saprouter"):
        if sec.get(opt):
            kwargs[opt] = sec[opt]
    return Connection(**kwargs)


def _read_table(conn, table: str, fields: list, where: str = "", max_rows: int = MAX_ROWS_PER_TEMPLATE) -> list:
    # Cluster-table aware preflight (Gemini gap #7). Refuses NO_GO plans
    # (e.g. PCL1/PCL2 with no WHERE) BEFORE making the RFC call that would
    # otherwise dump the source ECC database. For BSEG/RFBLG/KOCLU it caps the
    # row count and logs that we're touching a cluster table.
    where_dict = _where_to_dict(where) if where else {}
    on_hana = (os.environ.get("M4H_ECC_ON_HANA", "").lower() in ("1", "true", "yes"))
    try:
        from cluster_table_awareness import preflight, KIND_TRANSPARENT
        plan = preflight(table, where=where_dict, fields=fields,
                         requested_package_size=max_rows, on_hana=on_hana)
        if plan.verdict == "NO_GO":
            raise RuntimeError(
                f"cluster_table_awareness refused extraction of {table}: "
                f"{plan.warnings[0] if plan.warnings else 'unsafe extraction'}")
        if plan.kind != KIND_TRANSPARENT and not on_hana:
            # Honor the cap so a 5000-row BSEG fetch becomes 200 (memory-safe)
            max_rows = min(max_rows, plan.recommended_package_size)
    except ImportError:
        pass    # module not on path -> proceed unprotected (legacy behaviour)

    opts = [{"TEXT": where}] if where else []
    fld = [{"FIELDNAME": f} for f in fields]
    # DELIMITER='|' so multi-field rows split cleanly (without it RFC_READ_TABLE
    # returns fixed-width WA and the split produces garbage columns).
    res = conn.call("RFC_READ_TABLE", QUERY_TABLE=table, DELIMITER="|",
                    OPTIONS=opts, FIELDS=fld, ROWCOUNT=max_rows)
    cols = [f["FIELDNAME"] for f in res.get("FIELDS", [])]
    rows = []
    for r in res.get("DATA", []):
        parts = [p.strip() for p in r["WA"].split("|")]
        rows.append(dict(zip(cols, parts)))
    return rows, cols


_WHERE_KEY_RE = re.compile(r"\b([A-Z][A-Z0-9_]{1,29})\s*=\s*'([^']*)'")

def _where_to_dict(where_clause: str) -> dict:
    """Best-effort extract of column=value pins from an OPTIONS WHERE string
    (e.g. "BUKRS = '1010' AND GJAHR = '2026'"). Used only to feed
    cluster_table_awareness.preflight()'s header-keys check; non-equality
    predicates (BETWEEN, IN, LIKE) are ignored - the preflight then treats
    those columns as not pinned."""
    if not where_clause:
        return {}
    return dict(_WHERE_KEY_RE.findall(where_clause))


def _target_connection():
    """RFC connection to the TARGET S/4 (for loading data in), from local:target."""
    sec = json.loads(SECRETS.get_secret_value(SecretId="local:target")["SecretString"])
    from pyrfc import Connection
    return Connection(ashost=sec["ashost"], sysnr=sec.get("sysnr", "00"),
                      client=sec["client"], user=sec["user"],
                      passwd=sec.get("passwd") or sec.get("password"), lang="EN")


def _target_odata():
    """OData (HTTPS gateway) client to the TARGET S/4 — the door RFC can't open for
    transaction-ready partner creation. None if requests/odata_client unavailable."""
    try:
        from odata_client import ODataClient
        sec = json.loads(SECRETS.get_secret_value(SecretId="local:target")["SecretString"])
        port = int(os.environ.get("M4H_ODATA_PORT", "44300"))
        return ODataClient(sec["ashost"], sec["user"], sec.get("passwd") or sec.get("password"),
                           client=sec.get("client", "100"), port=port)
    except Exception:
        return None


def _emit_mc_csv(run_id: str, obj_name: str, rows: list, cols: list) -> str:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=cols)
    w.writeheader()
    w.writerows(rows)
    key = f"runs/{run_id}/data-migrator/mc/{obj_name}.csv"
    S3.put_object(Bucket=STAGING_BUCKET, Key=key, Body=buf.getvalue().encode(),
                  ContentType="text/csv")
    return f"s3://{STAGING_BUCKET}/{key}"


def _emit_idoc_xml(run_id: str, obj_name: str, idoc_type: str, rows: list) -> str:
    """Minimal IDoc XML envelope; real per-segment population is delegated
    to idoc-orchestrator using the segment definitions on the target."""
    body_parts = ['<?xml version="1.0" encoding="UTF-8"?>',
                  f'<{idoc_type}_BATCH count="{len(rows)}">']
    for r in rows:
        seg = "".join(f"<{k}>{v}</{k}>" for k, v in r.items())
        body_parts.append(f"<{idoc_type}>{seg}</{idoc_type}>")
    body_parts.append(f"</{idoc_type}_BATCH>")
    key = f"runs/{run_id}/data-migrator/idoc/{obj_name}.xml"
    S3.put_object(Bucket=STAGING_BUCKET, Key=key,
                  Body="\n".join(body_parts).encode(),
                  ContentType="application/xml")
    return f"s3://{STAGING_BUCKET}/{key}"


def _emit_ltmom_spec(run_id: str, obj_name: str, cols: list) -> str:
    spec = {"object": obj_name, "source": "ECC", "target": "S/4HANA",
            "fields": [{"source": c, "target": c, "transform": "identity"} for c in cols],
            "instructions": "LTMOM mapping is built manually on target; "
                            "this spec is the design input."}
    key = f"runs/{run_id}/data-migrator/ltmom/{obj_name}.json"
    S3.put_object(Bucket=STAGING_BUCKET, Key=key, Body=json.dumps(spec, indent=2).encode(),
                  ContentType="application/json")
    return f"s3://{STAGING_BUCKET}/{key}"


def _emit_currency_config(run_id: str, manifest: dict, csv_text: str) -> dict:
    """Write the currency-customizing deploy package (the prerequisite TCURV rate
    types + TCURF factors the target is missing) for controlled, transport-grade
    apply. Returns the artifact locations."""
    base = f"runs/{run_id}/data-migrator/config/exchange_rate_customizing"
    S3.put_object(Bucket=STAGING_BUCKET, Key=f"{base}.json",
                  Body=json.dumps(manifest, indent=2).encode(), ContentType="application/json")
    S3.put_object(Bucket=STAGING_BUCKET, Key=f"{base}.csv",
                  Body=csv_text.encode(), ContentType="text/csv")
    return {"manifest": f"s3://{STAGING_BUCKET}/{base}.json",
            "review_csv": f"s3://{STAGING_BUCKET}/{base}.csv"}


def _emit_key_map(run_id: str, km) -> dict:
    """Persist the run's source->target key registry as a first-class artifact:
    a JSON for programmatic lookup by later stages / dependent objects, and a CSV
    for audit. This is how transactional data follows remapped/renumbered keys."""
    base = f"runs/{run_id}/data-migrator/keymap/key_mapping"
    S3.put_object(Bucket=STAGING_BUCKET, Key=f"{base}.json",
                  Body=json.dumps(km.to_dict(), indent=2).encode(), ContentType="application/json")
    S3.put_object(Bucket=STAGING_BUCKET, Key=f"{base}.csv",
                  Body=km.to_csv().encode(), ContentType="text/csv")
    return {"registry": f"s3://{STAGING_BUCKET}/{base}.json",
            "audit_csv": f"s3://{STAGING_BUCKET}/{base}.csv"}


# ── Object → source-table mapping for batch-mode runs ────────────────────────
# When the runner invokes data-migrator without an explicit object_spec, we
# iterate over the stage-3 DAG and apply this canonical mapping per object.
DEFAULT_OBJECT_TABLES = {
    "Customer":          {"table": "KNA1", "fields": ["KUNNR", "NAME1", "LAND1", "ORT01"], "lane": "MC"},
    "Vendor":            {"table": "LFA1", "fields": ["LIFNR", "NAME1", "LAND1", "ORT01"], "lane": "MC"},
    "Material":          {"table": "MARA", "fields": ["MATNR", "MTART", "MATKL", "MEINS"], "lane": "MC"},
    "BusinessPartner":   {"table": "BUT000", "fields": ["PARTNER", "TYPE", "BPKIND", "BU_GROUP"], "lane": "MC"},
    "CompanyCode":       {"table": "T001", "fields": ["BUKRS", "BUTXT", "ORT01", "LAND1"], "lane": "MC"},
    "GLAccount":         {"table": "SKA1", "fields": ["KTOPL", "SAKNR", "XBILK"], "lane": "MC"},
    "CostCenter":        {"table": "CSKS", "fields": ["KOKRS", "KOSTL", "DATBI"], "lane": "MC"},
    "ProfitCenter":      {"table": "CEPC", "fields": ["KOKRS", "PRCTR", "DATBI"], "lane": "MC"},
    "FixedAsset":        {"table": "ANLA", "fields": ["BUKRS", "ANLN1", "ANLN2", "ANLKL", "TXT50"], "lane": "MC"},
    "Bank":              {"table": "BNKA", "fields": ["BANKS", "BANKL", "BANKA", "SWIFT", "BRNCH", "ORT01"], "lane": "MC"},
    "InternalOrder":     {"table": "AUFK", "fields": ["AUFNR", "AUART", "KTEXT", "KOKRS", "BUKRS"], "where": "AUTYP = '01'", "lane": "MC"},
    "Equipment":         {"table": "EQUI", "fields": ["EQUNR", "EQTYP"], "lane": "MC"},
    "FunctionalLocation": {"table": "IFLOT", "fields": ["TPLNR", "FLTYP"], "lane": "MC"},
    "Characteristic":    {"table": "CABN", "fields": ["ATNAM", "ATFOR", "ANZST", "ANZDZ"], "lane": "MC"},
    "Class":             {"table": "KLAH", "fields": ["CLASS", "KLART"], "lane": "MC"},
    "CostElementGroup":  {"table": "SETHEADER", "fields": ["SETNAME", "SUBCLASS"], "where": "SETCLASS = '0102'", "lane": "MC"},
    "ProfitCenterGroup": {"table": "SETHEADER", "fields": ["SETNAME", "SUBCLASS"], "where": "SETCLASS = '0106'", "lane": "MC"},
    "Project":           {"table": "PROJ", "fields": ["PSPID", "POST1"], "lane": "MC"},
    "PurchaseRequisition": {"table": "EBAN", "fields": ["BANFN", "BNFPO", "MATNR", "WERKS", "MENGE", "TXZ01", "PREIS"], "where": "LOEKZ = '' AND EBELN = ''", "lane": "MC"},
    "OpenSO":            {"table": "VBAK", "fields": ["VBELN", "AUART", "VKORG", "VTWEG", "SPART", "KUNNR"], "lane": "MC"},
    "PurchaseContract":  {"table": "EKKO", "fields": ["EBELN", "BSART", "LIFNR", "EKORG", "WAERS"], "where": "BSTYP = 'K'", "lane": "MC"},
    "Batch":             {"table": "MCH1", "fields": ["MATNR", "CHARG"], "lane": "MC"},
    "InventoryBalance":  {"table": "MARD", "fields": ["MATNR", "WERKS", "LGORT", "LABST"], "where": "LABST > '0'", "lane": "MC"},
    "Plant":             {"table": "T001W", "fields": ["WERKS", "NAME1", "LAND1"], "lane": "MC"},
    "ChartOfAccounts":   {"table": "T004", "fields": ["KTOPL", "KTPLT", "MWSKZ"], "lane": "MC"},
    "ControllingArea":   {"table": "TKA01", "fields": ["KOKRS", "BEZEI", "WAERS"], "lane": "MC"},
    "OpenPO":            {"table": "EKKO", "fields": ["EBELN", "BSART", "BUKRS", "EKORG", "EKGRP", "LIFNR", "WAERS"], "where": "BSTYP = 'F'", "lane": "MC"},
    "OpenAR":            {"table": "BSID", "fields": ["BUKRS", "KUNNR", "BELNR", "DMBTR", "SHKZG", "WAERS"], "lane": "MC"},
    "OpenAP":            {"table": "BSIK", "fields": ["BUKRS", "LIFNR", "BELNR", "DMBTR", "SHKZG", "WAERS"], "lane": "MC"},
    "BankStatements":    {"table": "FEBKO", "fields": ["KUKEY", "ESNUM", "BANKL", "BANKN"], "lane": "IDOC", "idoc_type": "FINSTA01"},
    "ExchangeRates":     {"table": "TCURR", "fields": ["KURST", "FCURR", "TCURR", "GDATU", "UKURS", "FFACT", "TFACT"], "lane": "IDOC", "idoc_type": "EXCHRATE_CREATE01"},
    "AssetMaster":       {"table": "ANLA", "fields": ["BUKRS", "ANLN1", "ANLN2", "ANLKL"], "lane": "MC"},
    "BOM":               {"table": "MAST", "fields": ["MATNR", "WERKS", "STLAN", "STLNR"], "lane": "MC"},
    "Routing":           {"table": "MAPL", "fields": ["MATNR", "WERKS", "PLNTY", "PLNNR"], "lane": "MC"},
    "WorkCenter":        {"table": "CRHD", "fields": ["OBJID", "ARBPL", "WERKS"], "lane": "MC"},

    # ── Extended Migration-Cockpit catalog (extract+emit lane = "MC") ───────────
    # The dispatcher reads source from ECC for each entry and emits the MC-staging
    # template; load into S/4 is done by the MC tool consuming those templates.
    # Verified extracts where probed live (the proven extract pattern).
    # MM
    "SourceList":            {"table": "EORD",  "fields": ["MATNR", "WERKS", "LIFNR", "EBELN", "ERDAT"], "lane": "MC"},
    "QuotaArrangement":      {"table": "EQUOT", "fields": ["MATNR", "WERKS", "QUNUM", "QUPOS"], "lane": "MC"},
    "PurchaseInfoRecord":    {"table": "EINA",  "fields": ["INFNR", "LIFNR", "MATNR", "MATKL", "MEINS"], "lane": "MC"},
    "ServiceMaster":         {"table": "ASMD",  "fields": ["ASNUM", "ASKTX", "MEINS", "MATKL"], "lane": "MC"},
    "ScheduleAgreementMM":   {"table": "EKKO",  "fields": ["EBELN", "BSART", "LIFNR", "EKORG", "WAERS"], "where": "BSTYP = 'L'", "lane": "MC"},
    "MaterialBOMHeader":     {"table": "STKO",  "fields": ["STLNR", "STLAL", "BMENG", "BMEIN", "STLST"], "lane": "MC"},
    "MaterialBOMItem":       {"table": "STPO",  "fields": ["STLNR", "STLKN", "IDNRK", "MENGE", "MEINS", "POSTP"], "lane": "MC"},
    "MaterialStock":         {"table": "MARD",  "fields": ["MATNR", "WERKS", "LGORT", "LABST"], "lane": "MC"},
    "StorageLocation":       {"table": "T001L", "fields": ["WERKS", "LGORT", "LGOBE"], "lane": "MC"},
    "MaterialClassification": {"table": "AUSP", "fields": ["OBJEK", "ATINN", "ATWRT", "KLART"], "lane": "MC"},
    "PricingConditionMM":    {"table": "KONP",  "fields": ["KNUMH", "KOPOS", "KSCHL", "KBETR"], "lane": "MC"},
    "ConsignmentStock":      {"table": "MKOL",  "fields": ["MATNR", "WERKS", "LIFNR", "LBLAB"], "lane": "MC"},
    # SD
    "CustomerMaterialInfo":  {"table": "KNMT",  "fields": ["KUNNR", "MATNR", "KDMAT", "POSTX"], "lane": "MC"},
    "SalesQuotation":        {"table": "VBAK",  "fields": ["VBELN", "AUART", "KUNNR", "VKORG", "VTWEG", "SPART"], "where": "VBTYP = 'B'", "lane": "MC"},
    "SalesInquiry":          {"table": "VBAK",  "fields": ["VBELN", "AUART", "KUNNR", "VKORG", "VTWEG", "SPART"], "where": "VBTYP = 'A'", "lane": "MC"},
    "SalesContract":         {"table": "VBAK",  "fields": ["VBELN", "AUART", "KUNNR", "VKORG", "VTWEG", "SPART"], "where": "VBTYP = 'G'", "lane": "MC"},
    "ScheduleAgreementSD":   {"table": "VBAK",  "fields": ["VBELN", "AUART", "KUNNR", "VKORG", "VTWEG", "SPART"], "where": "VBTYP = 'E'", "lane": "MC"},
    "CreditMaster":          {"table": "KNKK",  "fields": ["KUNNR", "KKBER", "KLIMK", "SKFOR"], "lane": "MC"},
    "CustomerHierarchy":     {"table": "KNVH",  "fields": ["HKUNNR", "KUNNR", "VKORG", "VTWEG", "SPART"], "lane": "MC"},
    "OutboundDelivery":      {"table": "LIKP",  "fields": ["VBELN", "VKORG", "VSTEL", "LFART", "KUNAG"], "lane": "MC"},
    "BillingDocument":       {"table": "VBRK",  "fields": ["VBELN", "FKART", "BUKRS", "WAERK", "NETWR"], "lane": "MC"},
    "PricingConditionSD":    {"table": "KONH",  "fields": ["KNUMH", "KSCHL", "KAPPL"], "lane": "MC"},
    # PP
    "ProductionVersion":     {"table": "MKAL",  "fields": ["MATNR", "WERKS", "VERID", "ADATU", "BDATU"], "lane": "MC"},
    "ProductionOrder":       {"table": "AUFK",  "fields": ["AUFNR", "AUART", "WERKS", "BUKRS"], "where": "AUTYP = '10'", "lane": "MC"},
    "PlannedOrder":          {"table": "PLAF",  "fields": ["PLNUM", "MATNR", "PWWRK", "GSMNG"], "lane": "MC"},
    "MRPArea":               {"table": "T001K", "fields": ["BWKEY", "BUKRS"], "lane": "MC"},
    "DemandManagement":      {"table": "PBED",  "fields": ["MATNR", "WERKS", "BDZEI", "BDMNG"], "lane": "MC"},
    # PS
    "WBSElement":            {"table": "PRPS",  "fields": ["POSID", "PSPNR", "OBJNR"], "lane": "MC"},
    "Network":               {"table": "AUFK",  "fields": ["AUFNR", "AUART", "WERKS", "BUKRS"], "where": "AUTYP = '20'", "lane": "MC"},
    "NetworkActivity":       {"table": "AFVC",  "fields": ["AUFPL", "APLZL", "VORNR", "LTXA1"], "lane": "MC"},
    # PM
    "MaintenancePlan":       {"table": "MPLA",  "fields": ["WARPL", "MPTYP", "STRAT"], "lane": "MC"},
    "MaintenanceTaskList":   {"table": "PLKO",  "fields": ["PLNNR", "PLNAL", "WERKS", "KTEXT"], "where": "PLNTY = 'A'", "lane": "MC"},
    "MeasuringPoint":        {"table": "IMPT",  "fields": ["POINT", "MPOBJ", "MPTYP"], "lane": "MC"},
    "MeasurementDocument":   {"table": "IMRG",  "fields": ["MDOCM", "POINT", "MDATE"], "lane": "MC"},
    "ServiceNotification":   {"table": "VIQMEL", "fields": ["QMNUM", "QMART", "QMTXT"], "lane": "MC"},
    "ServiceContract":       {"table": "VEDA",  "fields": ["VBELN", "VPOSN", "VBEGDAT", "VENDDAT"], "lane": "MC"},
    # QM
    "InspectionPlan":        {"table": "PLKO",  "fields": ["PLNNR", "PLNAL", "WERKS", "KTEXT"], "where": "PLNTY = 'Q'", "lane": "MC"},
    "InspectionMethod":      {"table": "QMTB",  "fields": ["PRUEFMETH", "WERKS"], "lane": "MC"},
    "InspectionCharacteristic": {"table": "QPMK", "fields": ["VERWMERKM", "WERKS", "KURZTEXT"], "lane": "MC"},
    "QualityInfoRecord":     {"table": "QINF",  "fields": ["MATNR", "LIFNR", "WERKS"], "lane": "MC"},
    "InspectionLot":         {"table": "QALS",  "fields": ["PRUEFLOS", "MATNR", "WERKS"], "lane": "MC"},
    "CatalogCode":           {"table": "QPGR",  "fields": ["KATALOGART", "CODEGRUPPE"], "lane": "MC"},
    # WM / EWM
    "StorageBin":            {"table": "LAGP",  "fields": ["LGNUM", "LGTYP", "LGPLA"], "lane": "MC"},
    "StockInBin":            {"table": "LQUA",  "fields": ["LGNUM", "LGTYP", "LGPLA", "MATNR", "GESME"], "lane": "MC"},
    "WarehouseTransferOrder": {"table": "LTAK", "fields": ["LGNUM", "TANUM", "BDATU"], "lane": "MC"},
    "HandlingUnit":          {"table": "VEKP",  "fields": ["VENUM", "VPOBJKEY", "EXIDV"], "lane": "MC"},
    # HR (mini-master)
    "EmployeeOrgData":       {"table": "PA0001", "fields": ["PERNR", "BUKRS", "WERKS", "BTRTL"], "lane": "MC"},
    "EmployeePersonalData":  {"table": "PA0002", "fields": ["PERNR", "VORNA", "NACHN"], "lane": "MC"},
    "EmployeeAddress":       {"table": "PA0006", "fields": ["PERNR", "ANSSA", "LAND1", "ORT01"], "lane": "MC"},
    # Classification & documents
    "ClassAssignment":       {"table": "AUSP",  "fields": ["OBJEK", "ATINN", "ATWRT", "KLART"], "lane": "MC"},
    "DocumentInfoRecord":    {"table": "DRAW",  "fields": ["DOKNR", "DOKAR", "DOKTL", "DOKVR"], "lane": "MC"},
    # Finance master (extensions)
    "HouseBankAccount":      {"table": "T012K", "fields": ["BUKRS", "HBKID", "HKTID"], "lane": "MC"},
    "AssetClass":            {"table": "ANKA",  "fields": ["ANLKL", "ANLKT"], "lane": "MC"},
    "AssetSubNumber":        {"table": "ANLB",  "fields": ["BUKRS", "ANLN1", "ANLN2", "AFABE"], "lane": "MC"},
    "DepreciationArea":      {"table": "T093",  "fields": ["AFAPL", "AFABE"], "lane": "MC"},
    "TaxCode":               {"table": "T007A", "fields": ["KALSM", "MWSKZ"], "lane": "MC"},
    "DunningArea":           {"table": "T047M", "fields": ["BUKRS", "MABER"], "lane": "MC"},
    # CO-FM (routed lanes, see BREADTH_TRACKER for evidence)
    "ActivityType":          {"table": "CSLA",  "fields": ["KOKRS", "LSTAR", "DATBI"], "lane": "MC"},
    "StatisticalKeyFigure":  {"table": "TKA03", "fields": ["KOKRS", "STAGR"], "lane": "MC"},
    "CommitmentItem":        {"table": "FMCI",  "fields": ["FIKRS", "FIPEX", "FIPOS"], "lane": "MC"},
    # Customizing / config (config-master extracts; lane MC for parity migration)
    "Currency":              {"table": "TCURC", "fields": ["WAERS", "ISOCD"], "lane": "MC"},
    "Country":               {"table": "T005",  "fields": ["LAND1", "LANDN", "ISO3"], "lane": "MC"},
    "Region":                {"table": "T005S", "fields": ["LAND1", "BLAND"], "lane": "MC"},
    "PaymentTerms":          {"table": "T052",  "fields": ["ZTERM", "TAGE2", "TAGE3"], "lane": "MC"},
    "UnitOfMeasure":         {"table": "T006",  "fields": ["MSEHI", "ISOCODE"], "lane": "MC"},
    "IncoTerm":              {"table": "TINC",  "fields": ["INCO1"], "lane": "MC"},
    # Address master
    "Address":               {"table": "ADRC",  "fields": ["ADDRNUMBER", "NAME1", "STREET", "CITY1", "COUNTRY"], "lane": "MC"},
    "Person":                {"table": "ADRP",  "fields": ["PERSNUMBER", "NAME_FIRST", "NAME_LAST"], "lane": "MC"},

    # ── Catalog batch 2 — document items, FI/MM/SD extensions, FM ─────────────
    # Doc items (extracted separately from headers; header is the parent extract)
    "SalesOrderItem":        {"table": "VBAP",  "fields": ["VBELN", "POSNR", "MATNR", "KWMENG", "VRKME", "NETWR"], "lane": "MC"},
    "PurchaseOrderItem":     {"table": "EKPO",  "fields": ["EBELN", "EBELP", "MATNR", "WERKS", "MENGE", "NETPR"], "lane": "MC"},
    "BillingItem":           {"table": "VBRP",  "fields": ["VBELN", "POSNR", "MATNR", "FKIMG", "NETWR"], "lane": "MC"},
    "DeliveryItem":          {"table": "LIPS",  "fields": ["VBELN", "POSNR", "MATNR", "LFIMG", "VRKME"], "lane": "MC"},
    "PRItem":                {"table": "EBAN",  "fields": ["BANFN", "BNFPO", "MATNR", "WERKS", "MENGE", "PREIS"], "lane": "MC"},
    # MM extensions
    "GoodsReceipt":          {"table": "MSEG",  "fields": ["MBLNR", "ZEILE", "MATNR", "WERKS", "BWART", "MENGE"], "lane": "MC"},
    "LogisticsInvoice":      {"table": "RBKP",  "fields": ["BELNR", "GJAHR", "LIFNR", "RMWWR", "WAERS"], "lane": "MC"},
    "StockTransportOrder":   {"table": "EKKO",  "fields": ["EBELN", "BSART", "BUKRS", "EKORG", "LIFNR"], "where": "BSTYP = 'F' AND BSART = 'UB'", "lane": "MC"},
    "PurchaseOrderHistory":  {"table": "EKBE",  "fields": ["EBELN", "EBELP", "BELNR", "VGABE", "MENGE"], "lane": "MC"},
    "BidInvitation":         {"table": "EKKO",  "fields": ["EBELN", "BSART", "LIFNR", "EKORG"], "where": "BSTYP = 'A'", "lane": "MC"},
    "VendorBankDetails":     {"table": "LFBK",  "fields": ["LIFNR", "BANKS", "BANKL", "BANKN"], "lane": "MC"},
    "CustomerBankDetails":   {"table": "KNBK",  "fields": ["KUNNR", "BANKS", "BANKL", "BANKN"], "lane": "MC"},
    # SD extensions
    "ScheduleLines":         {"table": "VBEP",  "fields": ["VBELN", "POSNR", "ETENR", "EDATU", "WMENG"], "lane": "MC"},
    "Shipment":              {"table": "VTTK",  "fields": ["TKNUM", "SHTYP", "TPLST"], "lane": "MC"},
    # PP / process
    "ProcessOrder":          {"table": "AUFK",  "fields": ["AUFNR", "AUART", "WERKS", "BUKRS"], "where": "AUTYP = '40'", "lane": "MC"},
    # FI extensions
    "AccountingDocHeader":   {"table": "BKPF",  "fields": ["BUKRS", "BELNR", "GJAHR", "BLART", "BLDAT"], "lane": "MC"},
    "AccountingDocItem":     {"table": "BSEG",  "fields": ["BUKRS", "BELNR", "GJAHR", "BUZEI", "DMBTR", "SHKZG"], "lane": "MC"},
    "AssetValues":           {"table": "ANLC",  "fields": ["BUKRS", "ANLN1", "ANLN2", "GJAHR", "AFABE"], "lane": "MC"},
    # FM (Funds Management)
    "FundsCenter":           {"table": "FMFCTR", "fields": ["FIKRS", "FICTR"], "lane": "MC"},
    "Fund":                  {"table": "FMFINCODE", "fields": ["FIKRS", "FINCODE"], "lane": "MC"},
    # Material / WM extras
    "MaterialUnitConversion": {"table": "MARM", "fields": ["MATNR", "MEINH", "UMREZ", "UMREN"], "lane": "MC"},
    "StorageTypeMaster":     {"table": "T331",  "fields": ["LGNUM", "LGTYP", "T331_LDESC"], "lane": "MC"},
    # Determinations / pricing tables
    "TaxDetermination":      {"table": "A053",  "fields": ["KAPPL", "KSCHL", "DATBI", "ALAND"], "lane": "MC"},
    "AccountDetermination":  {"table": "T030",  "fields": ["KTOPL", "KTOSL", "BWMOD"], "lane": "MC"},
}


# Cross-run migration ledger: the durable source->target record that makes re-runs
# idempotent (resume, don't duplicate). Stable key (not per run_id) so it accumulates.
LEDGER_KEY = "migration-ledger/key_mapping.json"


def _load_ledger(run_id: str = ""):
    """Load the cross-run migration ledger into a KeyMap.

    Two modes, chosen at runtime:

    * **DynamoDB mode** (production): if ``M4H_KEYMAP_TABLE`` env var is set AND
      ``PersistentKeyMap`` is importable, return a PersistentKeyMap. Writes during
      the run stream straight to DynamoDB (per-mapping, atomic, race-safe);
      resolves for dependent objects fall through to DynamoDB on miss.
    * **S3-blob fallback** (local/dev or when DDB isn't configured): same shape as
      before — load the single JSON blob and accumulate in memory.

    Returns ``None`` only if KeyMap itself is unimportable.
    """
    if KeyMap is None:
        return None
    table = os.environ.get("M4H_KEYMAP_TABLE", "").strip()
    if table and PersistentKeyMap is not None:
        try:
            return PersistentKeyMap(table_name=table, run_id=run_id or "",
                                    target_release=os.environ.get("M4H_TARGET_RELEASE", ""))
        except Exception:
            # Fall through to S3 fallback below; DDB connectivity blip shouldn't
            # halt the run when we have a working S3 alternative.
            pass
    try:
        obj = S3.get_object(Bucket=STAGING_BUCKET, Key=LEDGER_KEY)
        return KeyMap.from_dict(json.loads(obj["Body"].read()))
    except Exception:
        return KeyMap()


def _save_ledger(km) -> None:
    """Persist the (now-merged) ledger.

    For PersistentKeyMap, writes already streamed to DynamoDB during the run, so
    we only need to emit the audit-friendly per-run CSV (done by _emit_key_map).
    For plain KeyMap, dump the merged ledger to S3 as before so the next run
    reuses it.
    """
    if PersistentKeyMap is not None and isinstance(km, PersistentKeyMap):
        # DDB writes already happened; persistence_stats() gives the verdict.
        try:
            log_stage_event("", "data-migrator", "key_map_persisted", km.persistence_stats())
        except Exception:
            pass
        return
    try:
        S3.put_object(Bucket=STAGING_BUCKET, Key=LEDGER_KEY,
                      Body=json.dumps(km.to_dict(), indent=2).encode(),
                      ContentType="application/json")
    except Exception:
        pass


# Discovered target config is cached (it involves probe calls; ~minutes). Reuse across
# runs; re-discover only for a new target or when M4H_REDISCOVER=1.
DISCOVERED_CONFIG_KEY = "migration-ledger/discovered-config.json"


def _load_discovered_config():
    try:
        obj = S3.get_object(Bucket=STAGING_BUCKET, Key=DISCOVERED_CONFIG_KEY)
        return json.loads(obj["Body"].read())
    except Exception:
        return None


def _save_discovered_config(cfg) -> None:
    try:
        S3.put_object(Bucket=STAGING_BUCKET, Key=DISCOVERED_CONFIG_KEY,
                      Body=json.dumps(cfg, indent=2).encode(), ContentType="application/json")
    except Exception:
        pass


# ── Delta / CDC: extract only records changed since the last watermark ────────
# Delta mode (M4H_CDC_DELTA=1) filters each object's extraction by a change-date field
# >= the persisted watermark — incremental migration + the cutover delta load. NOTE:
# KNA1/LFA1 only carry ERDAT (created) — so customer/vendor delta catches NEW masters;
# CHANGED existing ones need change documents (CDHDR/CDPOS), a future enhancement.
CDC_DELTA = os.environ.get("M4H_CDC_DELTA", "0") == "1"
CDC_STATE_KEY = "migration-ledger/cdc-watermark.json"
CDC_FIELDS = {
    "Customer": ["ERDAT"], "Vendor": ["ERDAT"], "Material": ["LAEDA", "ERSDA"],
    "OpenPO": ["AEDAT"], "OpenAR": ["CPUDT"], "OpenAP": ["CPUDT"],
}


def _load_watermark():
    """Last CDC watermark (YYYYMMDD) — None on first run (=> full extract)."""
    if os.environ.get("M4H_CDC_WATERMARK"):
        return os.environ["M4H_CDC_WATERMARK"]
    try:
        obj = S3.get_object(Bucket=STAGING_BUCKET, Key=CDC_STATE_KEY)
        return json.loads(obj["Body"].read()).get("watermark")
    except Exception:
        return None


def _save_watermark(wm: str) -> None:
    try:
        S3.put_object(Bucket=STAGING_BUCKET, Key=CDC_STATE_KEY,
                      Body=json.dumps({"watermark": wm}).encode(), ContentType="application/json")
    except Exception:
        pass


def _cdc_where(obj: str, watermark: str) -> str:
    """Delta WHERE for an object: any of its change-date fields >= watermark."""
    fields = CDC_FIELDS.get(obj)
    if not (fields and watermark):
        return ""
    return "( " + " OR ".join("%s >= '%s'" % (f, watermark) for f in fields) + " )"


# Change documents (CDHDR) let the delta also catch CHANGED masters (not just NEW), which
# the date-field filter alone misses (KNA1/LFA1 have no change date). object -> (class, key).
CDC_CHANGE_DOC = {"Customer": ("DEBI", "KUNNR"), "Vendor": ("KRED", "LIFNR"),
                  "Material": ("MATERIAL", "MATNR")}


def _pack_opts(where: str) -> list:
    """Split a WHERE into <=72-char OPTIONS lines (RFC_READ_TABLE limit), space-padded."""
    lines, cur = [], ""
    for w in where.split():
        if cur and len(cur) + len(w) + 1 > 72:
            lines.append(cur)
            cur = ""
        cur += w + " "
    if cur.strip():
        lines.append(cur)
    return [{"TEXT": ln} for ln in lines]


def _cdc_changed_keys(conn, obj: str, watermark: str, cap: int = 20000) -> set:
    """Master keys CHANGED since the watermark, from change documents (CDHDR)."""
    spec = CDC_CHANGE_DOC.get(obj)
    if not (spec and watermark):
        return set()
    cls, _ = spec
    try:
        r = conn.call("RFC_READ_TABLE", QUERY_TABLE="CDHDR", DELIMITER="|",
                      OPTIONS=_pack_opts("OBJECTCLAS = '%s' AND UDATE >= '%s'" % (cls, watermark)),
                      FIELDS=[{"FIELDNAME": "OBJECTID"}], ROWCOUNT=cap)
        return {d["WA"].strip() for d in r.get("DATA", []) if d["WA"].strip()}
    except Exception:
        return set()


def _read_by_keys(conn, table: str, fields: list, keyfield: str, keys: list, chunk: int = 40) -> list:
    """Read master rows for a set of keys (chunked OR-list); rows as field-keyed dicts."""
    rows, keys = [], list(keys)
    for i in range(0, len(keys), chunk):
        where = " OR ".join("%s = '%s'" % (keyfield, k) for k in keys[i:i + chunk])
        try:
            r = conn.call("RFC_READ_TABLE", QUERY_TABLE=table, DELIMITER="|",
                          OPTIONS=_pack_opts(where),
                          FIELDS=[{"FIELDNAME": f} for f in fields], ROWCOUNT=0)
            cols = [f["FIELDNAME"] for f in r.get("FIELDS", [])]
            for d in r.get("DATA", []):
                rows.append(dict(zip(cols, [p.strip() for p in d["WA"].split("|")])))
        except Exception:
            pass
    return rows


def _load_dag(run_id: str) -> dict:
    """Load the routing DAG written by stage 3 (object-router)."""
    try:
        obj = S3.get_object(Bucket=STAGING_BUCKET, Key=f"runs/{run_id}/object-router/dag.json")
        return json.loads(obj["Body"].read())
    except Exception as ex:
        return {"nodes": [], "_load_error": str(ex)}


def _process_one_object(conn, run_id: str, node: dict, loader=None, cdc_watermark=None) -> dict:
    """Extract one object from ECC and emit lane-appropriate artifact."""
    obj_name = node.get("object", "UNKNOWN")
    lane = (node.get("lane") or "MC").upper()
    mapping = DEFAULT_OBJECT_TABLES.get(obj_name)

    if not mapping:
        # Unknown object — emit a placeholder so downstream stages don't blow up
        key = f"runs/{run_id}/data-migrator/skipped/{obj_name}.json"
        S3.put_object(Bucket=STAGING_BUCKET, Key=key,
                      Body=json.dumps({"object": obj_name, "lane": lane,
                                       "status": "skipped", "reason": "no source-table mapping"},
                                      indent=2).encode())
        return {"object": obj_name, "lane": lane, "status": "skipped",
                "reason": "no canonical mapping", "artifact": f"s3://{STAGING_BUCKET}/{key}"}

    table = mapping["table"]
    fields = mapping["fields"]
    base_where = mapping.get("where", "")
    # Delta/CDC: AND a change-date filter onto the base WHERE when a watermark is set.
    cdc_where = _cdc_where(obj_name, cdc_watermark) if cdc_watermark else ""
    delta_applied = bool(cdc_where)
    where = (f"( {base_where} ) AND {cdc_where}" if base_where and cdc_where
             else cdc_where or base_where)
    err_note = None
    try:
        rows, cols = _read_table(conn, table, fields, where)
    except Exception as e:
        if delta_applied:   # bad CDC field etc. — fall back to a full extract
            try:
                rows, cols = _read_table(conn, table, fields, base_where)
                delta_applied = False
                err_note = "cdc filter failed; full extract fallback"
            except Exception as e2:
                rows, cols = [], fields
                err_note = f"ECC read failed: {type(e2).__name__}: {str(e2)[:120]}"
        else:
            rows, cols = [], fields
            err_note = f"ECC read failed: {type(e).__name__}: {str(e)[:120]}"

    # Delta completeness: also pull masters CHANGED since the watermark (change docs),
    # which the date-field filter misses (e.g. a customer changed but not newly created).
    changed_via_cdhdr = 0
    if delta_applied and obj_name in CDC_CHANGE_DOC and not err_note:
        kf = CDC_CHANGE_DOC[obj_name][1]
        changed = _cdc_changed_keys(conn, obj_name, cdc_watermark)
        have = {r.get(kf) for r in rows}
        missing = [k for k in changed if k and k not in have]
        if missing:
            extra = _read_by_keys(conn, table, fields, kf, missing)
            rows = rows + extra
            changed_via_cdhdr = len(extra)

    artifacts = {}
    target_lane = mapping.get("lane", lane).upper()
    if target_lane == "MC":
        artifacts["mc_csv"] = _emit_mc_csv(run_id, obj_name, rows, cols)
    elif target_lane == "IDOC":
        idoc_type = mapping.get("idoc_type", obj_name)
        artifacts["idoc_xml"] = _emit_idoc_xml(run_id, obj_name, idoc_type, rows)
    elif target_lane == "LTMOM":
        artifacts["ltmom_spec"] = _emit_ltmom_spec(run_id, obj_name, cols)
        artifacts["sample_csv"] = _emit_mc_csv(run_id, f"{obj_name}_sample", rows[:1000], cols)
    else:
        artifacts["raw_csv"] = _emit_mc_csv(run_id, obj_name, rows, cols)

    result = {"object": obj_name, "lane": target_lane, "row_count": len(rows),
              "artifacts": artifacts, "note": err_note,
              "status": "ok" if err_note is None else "partial"}
    if cdc_watermark and delta_applied:   # only objects that actually have a CDC field
        result["delta"] = {"applied": True, "since": cdc_watermark,
                           "changed_rows": len(rows),
                           "changed_via_change_docs": changed_via_cdhdr}

    # Optionally LOAD the extracted rows into S/4 via the best mechanism (BAPI/IDoc).
    # Per-object cap overrides the global one (M4H_LOAD_MAX_ROWS_<OBJECT>) — e.g. run
    # ExchangeRates at volume while keeping side-effecting objects (BP/PO) at a few rows.
    if loader is not None and rows and loader.supported(obj_name):
        omax = int(os.environ.get("M4H_LOAD_MAX_ROWS_" + obj_name.upper(), LOAD_MAX_ROWS))
        try:
            result["load"] = loader.load_object(obj_name, rows, omax)
        except Exception as e:
            result["load"] = {"error": f"{type(e).__name__}: {str(e)[:160]}"}

    # RECONCILE: prove every record the BAPI said it created actually persisted in
    # the target's system of record (reads keys back; ties created == verified).
    if (loader is not None and Reconciler is not None and result.get("load")
            and "error" not in result["load"]):
        try:
            result["reconciliation"] = Reconciler(loader.c).reconcile(
                obj_name, result["load"], extracted=len(rows))
        except Exception as e:
            result["reconciliation"] = {"error": f"{type(e).__name__}: {str(e)[:160]}"}

    # ExchangeRates: run the currency-customizing READINESS check. Rates only post
    # when their TCURV type + TCURF factor exist in the target; this reports the
    # exact prerequisite delta (and its coverage impact) and emits a deploy package
    # the config team applies via transport — closing the gap to ~100% the right way.
    if (obj_name == "ExchangeRates" and loader is not None and rows
            and CurrencyConfigReconciler is not None):
        try:
            rec = CurrencyConfigReconciler(conn, loader.c)
            rep = rec.diff(rate_rows=rows)
            manifest, csv_text = rec.build_artifact(rep)
            artifacts.update(_emit_currency_config(run_id, manifest, csv_text))
            result["currency_config_readiness"] = {
                "coverage_before": rep["coverage_before"],
                "coverage_after_provisioning": rep["coverage_after_provisioning"],
                "missing_rate_types": rep["missing_rate_type_count"],
                "missing_factors": rep["missing_factor_count"],
                "deploy_package": {"manifest": artifacts.get("manifest"),
                                   "review_csv": artifacts.get("review_csv")},
            }
        except Exception as e:
            result["currency_config_readiness"] = {"error": f"{type(e).__name__}: {str(e)[:160]}"}
    return result


def _carve_out_programs(run_id, results, event):
    """Natuvion-class selective carve-out, embedded in the extraction stage.

    For each extracted object whose source table is carve-eligible, generate an
    optimized in-system extraction program: company-code (BUKRS) + fiscal-year
    (GJAHR) pushed into the WHERE, OPEN CURSOR + PACKAGE SIZE streaming, and
    dependency-aware header co-extraction (line items -> BKPF). Generation is
    deterministic + side-effect-free; in-system DEPLOY stays gated behind
    M4H_CARVE_DEPLOY + a live connection (not done here).

    Off by default; enabled by event["carve_out"] or M4H_CARVE_OUT=1.
    """
    spec = event.get("carve_out") or {}
    if not (spec or os.environ.get("M4H_CARVE_OUT", "0") == "1"):
        return None
    try:
        agent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "agent"))
        if agent_dir not in sys.path:
            sys.path.insert(0, agent_dir)
        from in_system_agent_generator import InSystemAgentGenerator
    except Exception as e:
        return {"enabled": True, "error": f"carve-out generator unavailable: {e}", "programs": []}

    gen = InSystemAgentGenerator()
    bukrs = spec.get("bukrs") or os.environ.get("M4H_CARVE_BUKRS", "")
    gjahr = spec.get("gjahr") or os.environ.get("M4H_CARVE_GJAHR", "")
    try:
        pkg = int(spec.get("package_size") or os.environ.get("M4H_CARVE_PKG", "50000"))
    except (TypeError, ValueError):
        pkg = 50000
    programs, errors, seen = [], [], set()
    for r in results:
        obj = r.get("object")
        table = ((DEFAULT_OBJECT_TABLES.get(obj) or {}).get("table") or "").upper()
        if not table or table in seen or table not in gen.registry:
            continue
        seen.add(table)
        try:
            g = gen.generate(table, bukrs=bukrs, gjahr=gjahr, package_size=pkg)
            artifact = None
            try:
                key = f"runs/{run_id}/data-migrator/carve-out/{g['program']}.abap"
                S3.put_object(Bucket=STAGING_BUCKET, Key=key,
                              Body=g["source"].encode(), ContentType="text/plain")
                artifact = f"s3://{STAGING_BUCKET}/{key}"
            except Exception:
                pass
            programs.append({"object": obj, "table": table, "program": g["program"],
                             "meta": g["meta"], "artifact": artifact})
        except Exception as e:
            errors.append({"object": obj, "table": table, "error": str(e)})
    return {"enabled": True, "engine": "Natuvion-class selective carve-out",
            "filters": {"bukrs": bukrs or "*", "gjahr": gjahr or "*", "package_size": pkg},
            "deploy_gated": os.environ.get("M4H_CARVE_DEPLOY", "0") == "1",
            "program_count": len(programs), "programs": programs, "errors": errors}


def lambda_handler(event, context):
    run_id = event.get("run_id", f"run-{int(time.time())}")
    mode = event.get("mode", "generate_templates")
    spec = event.get("object_spec") or {}
    log_stage_event(run_id, "data-migrator", "start", {"mode": mode, "object": spec.get("object")})

    # F2/F3/F5/F6 Phase B validation modes - exercise the new spine + dynamic-
    # schema + version-routing + benchmark paths against real SAP without the
    # DAG/batch-mode overhead. Tiny entry points; the validator functions live
    # further down.
    if mode == "phase_b_validate_f2":
        return _phase_b_validate_f2(event, run_id)
    if mode == "phase_b_validate_f3":
        return _phase_b_validate_f3(event, run_id)
    if mode == "phase_b_validate_f6":
        return _phase_b_validate_f6(event, run_id)
    if mode == "phase_b_validate_f5":
        return _phase_b_validate_f5(event, run_id)

    secret_id = (event.get("ecc_secret_id")
                 or os.environ.get("ECC_SECRET_ID")
                 or event.get("ecc_creds_arn")
                 or event.get("source_creds_arn")
                 or "local:ecc")
    if not secret_id:
        return {"status": "blocked", "reason": "ecc_secret_id / ecc_creds_arn required", "run_id": run_id}

    # ── Batch mode: no object_spec → iterate over stage-3 DAG ─────────────────
    if not spec.get("object"):
        dag = _load_dag(run_id)
        nodes = [n for n in dag.get("nodes", [])
                 if (n.get("lane") or "").upper() in ("MC", "IDOC", "LTMOM")]
        if not nodes:
            return {"status": "ok", "run_id": run_id, "mode": mode,
                    "note": "no MC/IDoc/LTMOM nodes in DAG — nothing to extract",
                    "dag_load": dag.get("_load_error")}
        try:
            conn = _ecc(secret_id)
        except Exception as e:
            log_stage_event(run_id, "data-migrator", "error", {"connect": str(e)})
            return {"status": "error", "reason": f"ECC connect failed: {e}", "run_id": run_id}

        # Optional S/4 loader (real write path) — only when M4H_LOAD_TO_S4=1
        loader = None
        discovered_config = None
        if LOAD_TO_S4 and UnifiedLoader is not None:
            try:
                tsec = json.loads(SECRETS.get_secret_value(SecretId="local:target")["SecretString"])
                tconn = _target_connection()
                loader = UnifiedLoader(tconn, own_logical_system=OWN_LOGICAL_SYSTEM,
                                       sender=IDOC_SENDER,
                                       client=tsec.get("client", "100"),
                                       target_sid=tsec.get("sid", "S4H"))
                # Enterprise transformation / value-mapping / DQ engine (Pillar 2).
                # Active only when M4H_TRANSFORM_RULES is configured; else a no-op.
                try:
                    import transformation_engine as _txe
                    loader.transformer = _txe.from_env()
                    if loader.transformer is not None:
                        log_stage_event(run_id, "data-migrator", "transform_engine_active",
                                        {"rules": os.environ.get("M4H_TRANSFORM_RULES")})
                except Exception as _te:
                    log_stage_event(run_id, "data-migrator", "transform_engine_skipped",
                                    {"reason": str(_te)[:160]})

                # BAPI field-coverage analysis (Gemini gap #3). Routes records
                # carrying CI_/ZZ_/J_1B fields the BAPI cannot transport to an
                # LTMC staging file instead of silently dropping them. Active
                # only when M4H_BAPI_COVERAGE_DIR is configured. The field
                # catalog ships from lambda/utils/bapi_field_catalog.py and
                # can be widened per landscape via M4H_BAPI_FIELD_CATALOG_JSON.
                _cov_dir = os.environ.get("M4H_BAPI_COVERAGE_DIR")
                if _cov_dir:
                    try:
                        from bapi_coverage import LtmcStagingEmitter
                        import bapi_field_catalog as _bfc
                        loader.bapi_coverage_emitter = LtmcStagingEmitter(_cov_dir)

                        # F3 - dynamic schema preferred. When M4H_DYNAMIC_SCHEMA_S3
                        # is set AND we have a target connection, introspect via
                        # DDIC; otherwise use the static baseline.
                        loader.bapi_field_catalog = _bfc.as_dict()
                        _dyn_s3 = os.environ.get("M4H_DYNAMIC_SCHEMA_S3", "").strip()
                        if _dyn_s3:
                            try:
                                from dynamic_schema_builder import build_all_schemas
                                from bapi_field_catalog import known_objects
                                dyn = build_all_schemas(
                                    sorted(known_objects()),
                                    conn=tconn, sid=tsec.get("sid", "S4H"),
                                    client=tsec.get("client", "100"),
                                    s4_release=os.environ.get("M4H_TARGET_RELEASE",
                                                              "UNKNOWN"),
                                    cache_s3_uri=_dyn_s3,
                                )
                                # Overlay dynamic results on top of static baseline:
                                # static fields stay as fallback; dynamic widens.
                                for obj, fields in dyn.items():
                                    base = loader.bapi_field_catalog.get(obj, set())
                                    loader.bapi_field_catalog[obj] = base | fields
                                log_stage_event(run_id, "data-migrator",
                                                "dynamic_schema_active",
                                                {"s3": _dyn_s3,
                                                 "objects_introspected": len(dyn)})
                            except Exception as _dse:
                                log_stage_event(run_id, "data-migrator",
                                                "dynamic_schema_skipped",
                                                {"reason": str(_dse)[:160]})
                        log_stage_event(run_id, "data-migrator",
                                        "bapi_coverage_active",
                                        {"dir": _cov_dir,
                                         "objects_covered": len(loader.bapi_field_catalog)})
                    except Exception as _ce:
                        log_stage_event(run_id, "data-migrator",
                                        "bapi_coverage_skipped",
                                        {"reason": str(_ce)[:160]})
                # Live source->target registry, shared across the run so dependent
                # objects (OpenPO -> Vendor) resolve refs; source conn for PO items.
                loader.key_map = _load_ledger(run_id)   # cross-run ledger -> idempotent re-runs (DDB-backed when M4H_KEYMAP_TABLE set)
                loader.source_conn = conn
                loader.odata = _target_odata()   # transaction-ready partner creation (OData)
                # Factories for the parallel worker pool (fresh per-worker connections):
                loader.target_conn_factory = _target_connection
                loader.source_conn_factory = lambda: _ecc(secret_id)
                loader.odata_factory = _target_odata
                # Auto-discover target org units/accounts so we adapt to THIS landscape
                # (not the appliance we were built on). Env overrides win; on failure we
                # keep the built-in defaults.
                if config_discovery is not None:
                    try:
                        _cfg = _load_discovered_config()
                        if _cfg is None or os.environ.get("M4H_REDISCOVER") == "1":
                            _cfg = config_discovery.discover(tconn)
                            _save_discovered_config(_cfg)
                            log_stage_event(run_id, "data-migrator", "config_discovered", _cfg["summary"])
                        else:
                            log_stage_event(run_id, "data-migrator", "config_cached", _cfg["summary"])
                        loader.po_org, loader.fi_org, loader.bp_org = _cfg["po"], _cfg["fi"], _cfg["bp"]
                        loader.cc_org = _cfg.get("co", {})
                        loader.asset_org = _cfg.get("asset", {})
                        discovered_config = _cfg["summary"]
                    except Exception as e:
                        log_stage_event(run_id, "data-migrator", "config_discovery_skipped", {"reason": str(e)[:160]})
                log_stage_event(run_id, "data-migrator", "load_enabled",
                                {"max_rows": LOAD_MAX_ROWS, "mechanisms": OBJECT_MECHANISM,
                                 "odata_partner_create": bool(loader.odata and loader.odata_ready())})
            except Exception as e:
                log_stage_event(run_id, "data-migrator", "load_disabled", {"reason": str(e)[:160]})

        # Delta/CDC: in delta mode, extract only records changed since the watermark.
        run_watermark = _load_watermark() if CDC_DELTA else None

        results = []
        for node in nodes:
            try:
                results.append(_process_one_object(conn, run_id, node, loader=loader,
                                                   cdc_watermark=run_watermark))
            except Exception as e:
                results.append({"object": node.get("object"), "status": "error",
                                "error": f"{type(e).__name__}: {str(e)[:200]}"})

        # Advance the watermark to today so the next delta run only picks up newer changes.
        new_watermark = time.strftime("%Y%m%d")
        if CDC_DELTA or _load_watermark() is None:
            _save_watermark(new_watermark)

        # Persist the live source->target key registry (built during the run as
        # objects loaded; consumed by dependent objects, then written for audit).
        key_map_info = None
        km = getattr(loader, "key_map", None) if loader else None
        if km is not None and km.to_rows():
            key_map_info = {**_emit_key_map(run_id, km), "stats": km.stats()}
            _save_ledger(km)   # persist the merged ledger for idempotent re-runs

        # Dead-letter: genuinely failed records across objects -> a report for targeted
        # reprocessing (a subsequent idempotent re-run picks these up; successes are skipped).
        dead_letters = [{"object": r.get("object"), **d}
                        for r in results for d in (r.get("load") or {}).get("dead_letter", [])]

        # CVI conflicts (Gemini gap #1) - appended into dead_letters here so they
        # ride the same dead-letter S3 artifact below. Uses unify_with_xrefs to
        # detect intercompany cycles (KNA1.LIFNR <-> LFA1.KUNNR) and produce a
        # two-phase load plan: phase 1 creates BP stubs, phase 2 attaches xrefs.
        cvi_info = None
        try:
            from cvi_mapper import unify_with_xrefs, detect_overlap as _cvi_overlap
            kna1_rows = next((((r.get("extract") or {}).get("rows") or [])
                              for r in results if r.get("object") == "Customer"), [])
            lfa1_rows = next((((r.get("extract") or {}).get("rows") or [])
                              for r in results if r.get("object") == "Vendor"), [])
            if kna1_rows and lfa1_rows:
                overlap_keys = _cvi_overlap(kna1_rows, lfa1_rows)
                mappings, conflicts, plan = unify_with_xrefs(kna1_rows, lfa1_rows)
                cvi_info = {
                    "overlap_partner_numbers": overlap_keys[:50],
                    "overlap_count": len(overlap_keys),
                    "legacy_keys_mapped": len(mappings),
                    "unique_bps": len({m.target_bp_id for m in mappings.values()}),
                    "merged_customer_vendor": sum(1 for m in mappings.values() if m.merged),
                    "conflicts_requiring_review": len(conflicts),
                    "two_phase_plan": plan.to_dict(),
                }
                cvi_key = f"runs/{run_id}/data-migrator/cvi_map.json"
                S3.put_object(
                    Bucket=STAGING_BUCKET, Key=cvi_key,
                    Body=json.dumps({
                        "mappings": {k: v.to_dict() for k, v in mappings.items()},
                        "conflicts": [c.to_dict() for c in conflicts],
                        "two_phase_plan": plan.to_dict(),
                    }, indent=2).encode(),
                    ContentType="application/json")
                cvi_info["artifact"] = f"s3://{STAGING_BUCKET}/{cvi_key}"
                log_stage_event(run_id, "data-migrator", "cvi_computed", cvi_info)
                for c in conflicts:
                    dead_letters.append({
                        "object": "BusinessPartner",
                        "reason": "CVI_CONFLICT",
                        "kna1_id": c.legacy_kna1_id,
                        "lfa1_id": c.legacy_lfa1_id,
                        "msg": c.reason,
                        "detail": c.detail,
                    })
        except Exception as _ce:
            log_stage_event(run_id, "data-migrator", "cvi_skipped",
                            {"reason": str(_ce)[:160]})

        dead_letter_info = None
        if dead_letters:
            dkey = f"runs/{run_id}/data-migrator/dead-letter/failed_records.json"
            S3.put_object(Bucket=STAGING_BUCKET, Key=dkey,
                          Body=json.dumps(dead_letters, indent=2).encode(),
                          ContentType="application/json")
            dead_letter_info = {"failed_records": len(dead_letters),
                                "artifact": f"s3://{STAGING_BUCKET}/{dkey}",
                                "reprocess": "idempotent re-run reloads these; loaded records are skipped"}

        # LTMC handoffs (Gemini follow-up #4). When bapi_coverage routes a
        # record to LTMC staging (BAPI lacks the field), the load result
        # carries an ltmc_handoff dict. Collect them ALL here so we can:
        #   - report the pending-LTMC-import count in the run summary
        #   - seal an "ltmc_pending" block into the hash chain so any tamper
        #     of the staging file is detectable
        ltmc_handoffs = []
        for r in results:
            for item in (r.get("load") or {}).get("ltmc_handoffs") or []:
                ltmc_handoffs.append({"object": r.get("object"), **item})
            # Also catch single-handoff style returned from _load_one:
            for record_load in (r.get("load") or {}).get("records") or []:
                handoff = record_load.get("ltmc_handoff")
                if handoff:
                    ltmc_handoffs.append({"object": r.get("object"), **handoff})

        ltmc_pending_info = None
        if ltmc_handoffs:
            ltmc_key = f"runs/{run_id}/data-migrator/ltmc_handoffs.json"
            S3.put_object(
                Bucket=STAGING_BUCKET, Key=ltmc_key,
                Body=json.dumps(ltmc_handoffs, indent=2).encode(),
                ContentType="application/json")
            ltmc_pending_info = {
                "pending_count": len(ltmc_handoffs),
                "objects_with_pending": sorted({h["object"] for h in ltmc_handoffs}),
                "artifact": f"s3://{STAGING_BUCKET}/{ltmc_key}",
                "note": "Gate: cutover must NOT proceed until each pending "
                        "LTMC handoff is confirmed imported in the Migration "
                        "Cockpit and reconciled. See EvidencePack.cutover_verdict.",
            }
            log_stage_event(run_id, "data-migrator", "ltmc_pending", ltmc_pending_info)

        # Write batch summary so downstream validator can read it
        loaded_to_s4 = sum((r.get("load", {}) or {}).get("created_in_s4", 0) for r in results)
        recon_reports = [r["reconciliation"] for r in results
                         if isinstance(r.get("reconciliation"), dict)
                         and "error" not in r["reconciliation"]]
        summary = {"run_id": run_id, "mode": mode, "object_count": len(results),
                   "ok_count": sum(1 for r in results if r.get("status") == "ok"),
                   "partial_count": sum(1 for r in results if r.get("status") == "partial"),
                   "error_count": sum(1 for r in results if r.get("status") == "error"),
                   "skipped_count": sum(1 for r in results if r.get("status") == "skipped"),
                   "load_to_s4_enabled": bool(loader),
                   "objects_created_in_s4": loaded_to_s4,
                   "cdc": {"mode": "delta" if CDC_DELTA else "full",
                           "watermark_used": run_watermark, "next_watermark": new_watermark,
                           "changed_rows_extracted": sum((r.get("delta") or {}).get("changed_rows", 0)
                                                         for r in results if r.get("delta"))},
                   "idempotency": {"newly_created": loaded_to_s4,
                                   "reused_from_ledger": sum((r.get("load", {}) or {}).get("reused_from_ledger", 0)
                                                             for r in results)},
                   "discovered_config": discovered_config,
                   "reconciliation": Reconciler.rollup(recon_reports) if Reconciler else None,
                   "support_compliance": compliance.audit(results) if compliance else None,
                   "key_mapping": key_map_info,
                   "dead_letter": dead_letter_info,
                   "cvi": cvi_info,
                   "ltmc_pending": ltmc_pending_info,
                   "carve_out": _carve_out_programs(run_id, results, event),
                   "results": results}
        # Pillar 4 — cryptographic audit chain over this run's verifiable actions.
        # Each block (data load, key-map, reconciliation, carve-out) is SHA-256
        # hash-chained to the previous, giving auditors tamper-evident assurance.
        try:
            from reconciler import HashChainLedger
            _chain = HashChainLedger(run_id=run_id)
            _chain.append("data_load", {"object_count": len(results),
                                        "created_in_s4": loaded_to_s4})
            if key_map_info:
                _chain.append("key_map", key_map_info.get("stats", {}))
            # Seal one block per LTMC handoff so the chain bears witness to
            # the staging file. cutover_verdict reads this to enforce
            # "no GO until LTMC imports confirmed."
            for handoff in (ltmc_handoffs or []):
                _chain.append("ltmc_pending", {
                    "object": handoff.get("object"),
                    "csv_path": handoff.get("csv_path"),
                    "records": handoff.get("records"),
                    "delta_fields": handoff.get("delta_fields"),
                    "status": "PENDING_LTMC_IMPORT",
                })
            if summary.get("reconciliation"):
                _chain.append("reconciliation", summary["reconciliation"])
            if summary.get("carve_out"):
                _chain.append("carve_out",
                              {"program_count": summary["carve_out"].get("program_count")})
            summary["audit_chain"] = {"head_hash": _chain.head(),
                                      "blocks": _chain.block_count(),
                                      "verification": _chain.verify()}
            S3.put_object(Bucket=STAGING_BUCKET,
                          Key=f"runs/{run_id}/data-migrator/audit_chain.jsonl",
                          Body=_chain.dump_jsonl().encode(),
                          ContentType="application/x-ndjson")
        except Exception as _ce:
            summary["audit_chain"] = {"error": str(_ce)[:160]}

        S3.put_object(Bucket=STAGING_BUCKET,
                      Key=f"runs/{run_id}/data-migrator/summary.json",
                      Body=json.dumps(summary, default=str, indent=2).encode(),
                      ContentType="application/json")
        log_stage_event(run_id, "data-migrator", "ok", summary)
        return {"status": "success", **summary}

    # ── Single-object mode (legacy) ───────────────────────────────────────────
    obj_name = spec.get("object", "UNKNOWN")
    table = spec.get("source_table", obj_name)
    fields = spec.get("fields", [])
    where = spec.get("where_clause", "")
    lane = (spec.get("lane") or "MC").upper()

    try:
        conn = _ecc(secret_id)
        rows, cols = _read_table(conn, table, fields, where)
    except Exception as e:
        log_stage_event(run_id, "data-migrator", "error", {"ecc_read": str(e)})
        return {"status": "error", "reason": f"ECC read failed: {e}", "run_id": run_id}

    artifacts = {}
    if lane == "MC":
        artifacts["mc_csv"] = _emit_mc_csv(run_id, obj_name, rows, cols)
    elif lane == "IDOC":
        idoc_type = spec.get("idoc_type", obj_name)
        artifacts["idoc_xml"] = _emit_idoc_xml(run_id, obj_name, idoc_type, rows)
    elif lane == "LTMOM":
        artifacts["ltmom_spec"] = _emit_ltmom_spec(run_id, obj_name, cols)
        artifacts["sample_csv"] = _emit_mc_csv(run_id, f"{obj_name}_sample", rows[:1000], cols)
    else:
        artifacts["raw_csv"] = _emit_mc_csv(run_id, obj_name, rows, cols)

    summary = {"run_id": run_id, "status": "ok", "object": obj_name, "lane": lane,
               "row_count": len(rows), "artifacts": artifacts}
    log_stage_event(run_id, "data-migrator", "ok", summary)
    return summary


# ─────────────────────────────────────────────────────────────────────────────
# Phase B validators
# ─────────────────────────────────────────────────────────────────────────────
def _phase_b_validate_f2(event, run_id):
    """F2 Phase B - drive MaterialSpineOrchestrator against the live S/4 target.

    Loads `count` synthetic Material records (default 3) via BAPI_MATERIAL_SAVEDATA
    and reports the per-record LoadResult, PersistentKeyMap writes, and stats.

    Payload shape::

        { "mode": "phase_b_validate_f2",
          "run_id": "f2-phaseb-001",
          "count": 3,
          "prefix": "F2PHASEB",
          "target_secret_id": "migrate4hana/prod/s4hana-credentials" }
    """
    target_secret_id = event.get("target_secret_id") or "migrate4hana/prod/s4hana-credentials"
    count   = int(event.get("count", 3))
    prefix  = event.get("prefix", "F2PHASEB")

    # Open target connection
    try:
        tsec = json.loads(SECRETS.get_secret_value(SecretId=target_secret_id)["SecretString"])
        from pyrfc import Connection   # type: ignore
        tconn = Connection(
            ashost=tsec["ashost"], sysnr=tsec.get("sysnr", "00"),
            client=tsec["client"], user=tsec["user"],
            passwd=tsec.get("passwd") or tsec.get("password"),
            lang=tsec.get("lang", "EN"),
        )
    except Exception as e:
        return {"status": "error", "phase": "connect_s4", "run_id": run_id,
                "error": f"{type(e).__name__}: {str(e)[:240]}"}

    # PersistentKeyMap pointed at the real DDB table
    try:
        from key_map import PersistentKeyMap
        ddb_table = os.environ.get("M4H_KEYMAP_TABLE", "migrate4hana-key-map-prod")
        km = PersistentKeyMap(table_name=ddb_table, run_id=run_id,
                              target_release=os.environ.get("M4H_TARGET_RELEASE", "S4HANA_UNKNOWN"))
    except Exception as e:
        km = None
        log_stage_event(run_id, "data-migrator", "phaseB_keymap_skipped",
                        {"reason": str(e)[:160]})

    # Drive the spine
    try:
        from material_spine import MaterialSpineOrchestrator
    except Exception as e:
        return {"status": "error", "phase": "import_spine", "run_id": run_id,
                "error": f"{type(e).__name__}: {str(e)[:240]}"}

    orch = MaterialSpineOrchestrator(tconn, key_map=km)

    # Synthetic records - keep the field set tight so a Phase B validation works
    # against any S/4 release without needing customer customizing.
    rows = []
    for i in range(count):
        rows.append({
            "MATNR": f"{prefix}_{i:04d}",
            "MTART": "HALB",        # universally supported semi-finished
            "MBRSH": "M",           # mechanical industry
            "MEINS": "EA",
            "MAKTX": f"Phase B test material {i:04d}",
        })

    results = orch.load_many(rows)
    summary = {
        "run_id":     run_id,
        "status":     "ok",
        "phase":      "f2_material_spine",
        "target":     {"sid": tsec.get("sid"), "client": tsec.get("client"),
                       "ashost": tsec.get("ashost")},
        "count":      count,
        "results":    [r.to_dict() for r in results],
        "spine_stats": orch.stats.to_dict(),
        "key_map_writes": (km.persistence_stats() if km is not None else None),
    }
    log_stage_event(run_id, "data-migrator", "phaseB_f2_complete",
                    {"created": orch.stats.created, "dead_letter": orch.stats.dead_letter})
    try:
        tconn.close()
    except Exception:
        pass
    return summary


def _phase_b_validate_f3(event, run_id):
    """F3 Phase B - drive dynamic_schema_builder against the live S/4 target.

    Calls DD_BAPI_PARAMETER_GET on the target, compiles the field set, writes
    the S3 cache, and returns the compiled CachedSchema.

    Payload shape::

        { "mode": "phase_b_validate_f3",
          "run_id": "f3-phaseb-001",
          "object_type": "Material",
          "target_secret_id": "migrate4hana/prod/s4hana-credentials",
          "force_refresh": true }
    """
    target_secret_id = event.get("target_secret_id") or "migrate4hana/prod/s4hana-credentials"
    object_type      = event.get("object_type", "Material")
    force_refresh    = bool(event.get("force_refresh", True))

    try:
        tsec = json.loads(SECRETS.get_secret_value(SecretId=target_secret_id)["SecretString"])
        from pyrfc import Connection   # type: ignore
        tconn = Connection(
            ashost=tsec["ashost"], sysnr=tsec.get("sysnr", "00"),
            client=tsec["client"], user=tsec["user"],
            passwd=tsec.get("passwd") or tsec.get("password"),
            lang=tsec.get("lang", "EN"),
        )
    except Exception as e:
        return {"status": "error", "phase": "connect_s4", "run_id": run_id,
                "error": f"{type(e).__name__}: {str(e)[:240]}"}

    # Try each RFC entry point directly so we capture and surface the real
    # error responses (build_schema falls back silently, which hides why the
    # live introspection didn't work).
    diag = {"dd_bapi_param_get": None, "get_function_interface": None,
            "dd03l_read": None}
    try:
        from dynamic_schema_builder import (
            introspect_via_dd_bapi_parameter_get, introspect_via_dd03l,
            introspect_via_get_function_interface,
            compile_field_set_from_dd_bapi, compile_field_set_from_dd03l,
            compile_field_set_from_function_interface,
            build_schema,
        )
    except Exception as e:
        return {"status": "error", "phase": "import_dynamic_schema",
                "run_id": run_id, "error": f"{type(e).__name__}: {str(e)[:240]}"}

    bapi = "BAPI_MATERIAL_SAVEDATA" if object_type == "Material" \
           else f"BAPI_{object_type.upper()}_CREATE"

    # 1) DD_BAPI_PARAMETER_GET direct probe (older releases only)
    try:
        params = introspect_via_dd_bapi_parameter_get(tconn, bapi)
        diag["dd_bapi_param_get"] = {"ok": True, "param_count": len(params),
                                      "compiled_fields": sorted(compile_field_set_from_dd_bapi(params))[:30]}
    except Exception as e:
        diag["dd_bapi_param_get"] = {"ok": False,
                                      "error": f"{type(e).__name__}: {str(e)[:300]}"}

    # 2) RFC_GET_FUNCTION_INTERFACE direct probe (universally available)
    try:
        iface = introspect_via_get_function_interface(tconn, bapi)
        fields = sorted(compile_field_set_from_function_interface(iface))
        diag["get_function_interface"] = {
            "ok": True,
            "param_count": len(iface),
            "param_summary": [
                {"name": p.get("PARAMETER"), "class": p.get("PARAMCLASS"),
                 "tabname": p.get("TABNAME"), "field_count": len(p.get("FIELDS") or [])}
                for p in iface[:10]
            ],
            "compiled_field_count": len(fields),
            "compiled_fields_sample": fields[:40],
        }
    except Exception as e:
        diag["get_function_interface"] = {"ok": False,
                                           "error": f"{type(e).__name__}: {str(e)[:300]}"}

    # 3) DD03L direct probe (read structure for the BAPI's function-module name)
    try:
        rows = introspect_via_dd03l(tconn, bapi)
        diag["dd03l_read"] = {"ok": True, "row_count": len(rows),
                               "compiled_fields": sorted(compile_field_set_from_dd03l(rows))[:30]}
    except Exception as e:
        diag["dd03l_read"] = {"ok": False,
                               "error": f"{type(e).__name__}: {str(e)[:300]}"}

    # 3) Full build_schema (fallback chain) for the actual cache write
    try:
        schema = build_schema(
            object_type,
            conn=tconn,
            sid=tsec.get("sid", "S4H"),
            client=tsec.get("client", "100"),
            s4_release=os.environ.get("M4H_TARGET_RELEASE", "S4HANA_2023"),
            cache_s3_uri=os.environ.get("M4H_DYNAMIC_SCHEMA_S3",
                                        f"s3://{STAGING_BUCKET}/dynamic-schema"),
            force_refresh=force_refresh,
        )
    except Exception as e:
        return {"status": "error", "phase": "build_schema", "run_id": run_id,
                "error": f"{type(e).__name__}: {str(e)[:240]}", "diag": diag}
    finally:
        try:
            tconn.close()
        except Exception:
            pass

    return {
        "run_id":   run_id,
        "status":   "ok",
        "phase":    "f3_dynamic_schema",
        "object":   object_type,
        "bapi":     bapi,
        "diag":     diag,
        "schema_source": schema.source,
        "field_count":   len(schema.fields),
        "sample_fields": schema.fields[:20],
    }


def _resolve_routing(source_code: str, target_code: str, source_db=None):
    """Helper - resolve a version_matrix RoutingPlan for the given pair.
    Returns ``(plan_dict, error_str)``. Either or both may be None."""
    try:
        from version_matrix import routing_for_pair, VersionIncompatibilityError
    except Exception as e:
        return None, f"version_matrix unimportable: {e}"
    try:
        plan = routing_for_pair(source_code, target_code, source_db=source_db)
        return plan.to_dict(), None
    except Exception as e:
        return None, f"{type(e).__name__}: {str(e)[:200]}"


def _phase_b_validate_f6(event, run_id):
    """F6 Phase B - validate that a saved version selection compiles into a
    RoutingPlan whose tags actually shape extract behaviour.

    Two-part proof:
      1. Resolve the routing plan from (source_code, target_code, source_db)
         either from the event payload or from auto-detection via RFC.
      2. Apply the plan's ``package_size`` to a real RFC_READ_TABLE call
         against the live ECC, and confirm the row-count cap matches the plan.

    Payload shape::

        { "mode": "phase_b_validate_f6",
          "run_id": "f6-phaseb-001",
          "source_code": "ECC60_EHP8",        # optional - auto-detect if absent
          "target_code": "S4HANA_2023",       # optional - auto-detect if absent
          "source_db":   "HANA",              # optional override
          "ecc_secret_id": "migrate4hana/prod/sap-credentials",
          "probe_table": "KNA1",
          "probe_fields": ["KUNNR", "NAME1"] }
    """
    ecc_secret_id = (event.get("ecc_secret_id")
                     or os.environ.get("ECC_SECRET_ID")
                     or "migrate4hana/prod/sap-credentials")
    src_code = event.get("source_code")
    tgt_code = event.get("target_code")
    src_db   = event.get("source_db")
    probe_table  = event.get("probe_table", "KNA1")
    probe_fields = event.get("probe_fields", ["KUNNR", "NAME1", "LAND1"])

    diag = {"detection": None, "routing_plan": None, "probe": None}

    # Open the ECC connection
    try:
        conn = _ecc(ecc_secret_id)
    except Exception as e:
        return {"status": "error", "phase": "connect_ecc", "run_id": run_id,
                "error": f"{type(e).__name__}: {str(e)[:240]}"}

    # If the caller didn't supply the version codes, auto-detect via RFC_SYSTEM_INFO
    if not src_code:
        try:
            from version_matrix import detect_source_ecc_version
            info = conn.call("RFC_SYSTEM_INFO")
            detected = detect_source_ecc_version(info)
            if detected:
                src_code = detected.code
                if not src_db:
                    src_db = detected.db_default
                diag["detection"] = {"source_code": src_code,
                                      "source_db": src_db,
                                      "rfc_release": info.get("RFCSI_EXPORT", {}).get("RFCSAPRL"),
                                      "rfc_dbsys":   info.get("RFCSI_EXPORT", {}).get("RFCDBSYS")}
            else:
                diag["detection"] = {"error": "RFC_SYSTEM_INFO returned an unmapped release",
                                      "raw": info.get("RFCSI_EXPORT")}
        except Exception as e:
            diag["detection"] = {"error": f"{type(e).__name__}: {str(e)[:240]}"}

    # Fall back to a sensible default target if not specified
    tgt_code = tgt_code or "S4HANA_2023"

    # Resolve routing plan
    if not src_code:
        try: conn.close()
        except Exception: pass
        return {"status": "error", "phase": "resolve_source_version",
                "run_id": run_id, "diag": diag,
                "error": "could not resolve source ECC version (pass source_code explicitly)"}

    plan, err = _resolve_routing(src_code, tgt_code, source_db=src_db)
    if err:
        try: conn.close()
        except Exception: pass
        return {"status": "error", "phase": "resolve_routing", "run_id": run_id,
                "diag": diag, "error": err}
    diag["routing_plan"] = plan

    # Apply the routing plan's package_size as the ROWCOUNT cap on a live probe
    cap = int(plan["package_size"])
    try:
        t0 = time.time()
        resp = conn.call(
            "RFC_READ_TABLE",
            QUERY_TABLE=probe_table,
            FIELDS=[{"FIELDNAME": f} for f in probe_fields],
            ROWCOUNT=cap,
        )
        elapsed_ms = int((time.time() - t0) * 1000)
        rows = resp.get("DATA") or []
        diag["probe"] = {"ok": True,
                          "table": probe_table,
                          "package_size_applied": cap,
                          "rows_returned": len(rows),
                          "elapsed_ms": elapsed_ms,
                          "throughput_rows_per_sec":
                              round(len(rows) / (elapsed_ms / 1000), 1) if elapsed_ms else None}
    except Exception as e:
        diag["probe"] = {"ok": False,
                          "error": f"{type(e).__name__}: {str(e)[:240]}"}
    finally:
        try: conn.close()
        except Exception: pass

    return {
        "run_id":      run_id,
        "status":      "ok",
        "phase":       "f6_version_routing",
        "source_code": src_code,
        "target_code": tgt_code,
        "source_db":   src_db,
        "extract_strategy":     plan["extract_strategy"],
        "package_size":         plan["package_size"],
        "template_format":      plan["template_format"],
        "fargate_fan_out":      plan["fargate_fan_out"],
        "cluster_read_safety":  plan["cluster_read_safety"],
        "odata_ltmc_supported": plan["odata_ltmc_supported"],
        "diag":        diag,
    }


def _percentile(values, p):
    if not values:
        return 0.0
    s = sorted(values)
    import math
    k = (len(s) - 1) * (p / 100.0)
    lo, hi = math.floor(k), math.ceil(k)
    if lo == hi:
        return float(s[int(k)])
    return s[lo] + (s[hi] - s[lo]) * (k - lo)


def _phase_b_validate_f5(event, run_id):
    """F5 Phase B - benchmark the spine path against real S/4 with per-record
    latency capture. Returns the same BenchmarkResult shape as the offline
    harness so SCALE_BENCHMARK.md can drop the numbers in directly.

    Payload shape::

        { "mode": "phase_b_validate_f5",
          "run_id": "f5-phaseb-001",
          "count": 25,
          "prefix": "F5PHASEB",
          "target_secret_id": "migrate4hana/prod/s4hana-credentials" }
    """
    target_secret_id = event.get("target_secret_id") or "migrate4hana/prod/s4hana-credentials"
    count   = int(event.get("count", 25))
    prefix  = event.get("prefix", "F5PHASEB")

    try:
        tsec = json.loads(SECRETS.get_secret_value(SecretId=target_secret_id)["SecretString"])
        from pyrfc import Connection   # type: ignore
        tconn = Connection(
            ashost=tsec["ashost"], sysnr=tsec.get("sysnr", "00"),
            client=tsec["client"], user=tsec["user"],
            passwd=tsec.get("passwd") or tsec.get("password"),
            lang=tsec.get("lang", "EN"),
        )
    except Exception as e:
        return {"status": "error", "phase": "connect_s4", "run_id": run_id,
                "error": f"{type(e).__name__}: {str(e)[:240]}"}

    try:
        from material_spine import MaterialSpineOrchestrator
        from key_map import PersistentKeyMap
    except Exception as e:
        return {"status": "error", "phase": "import_spine", "run_id": run_id,
                "error": f"{type(e).__name__}: {str(e)[:240]}"}

    ddb_table = os.environ.get("M4H_KEYMAP_TABLE", "migrate4hana-key-map-prod")
    km = PersistentKeyMap(table_name=ddb_table, run_id=run_id)
    orch = MaterialSpineOrchestrator(tconn, key_map=km)

    # Build records up front so generation cost isn't in the latency window
    records = []
    for i in range(count):
        records.append({
            "MATNR": f"{prefix}_{run_id[-6:]}_{i:04d}",
            "MTART": "HALB",
            "MBRSH": "M",
            "MEINS": "EA",
            "MAKTX": f"Phase B perf {i:04d}",
        })

    latencies_ms = []
    status_breakdown = {}
    dead_letter_codes = {}
    ext_rows_total = 0

    t0 = time.perf_counter()
    for row in records:
        r0 = time.perf_counter()
        res = orch.load_one(row)
        latencies_ms.append((time.perf_counter() - r0) * 1000)
        status_breakdown[res.status] = status_breakdown.get(res.status, 0) + 1
        if res.dead_letter:
            dead_letter_codes[res.dead_letter] = dead_letter_codes.get(res.dead_letter, 0) + 1
        ext_rows_total += res.extension_rows
    wall_clock_s = round(time.perf_counter() - t0, 3)

    try:
        tconn.close()
    except Exception:
        pass

    return {
        "run_id":             run_id,
        "status":             "ok",
        "phase":              "f5_spine_benchmark",
        "object_type":        "Material",
        "count":              count,
        "wall_clock_s":       wall_clock_s,
        "throughput_per_sec": round(count / wall_clock_s, 2) if wall_clock_s else 0.0,
        "p50_ms":             round(_percentile(latencies_ms, 50), 1),
        "p90_ms":             round(_percentile(latencies_ms, 90), 1),
        "p99_ms":             round(_percentile(latencies_ms, 99), 1),
        "p999_ms":            round(_percentile(latencies_ms, 99.9), 1),
        "min_ms":             round(min(latencies_ms), 1) if latencies_ms else 0,
        "max_ms":             round(max(latencies_ms), 1) if latencies_ms else 0,
        "status_breakdown":   status_breakdown,
        "dead_letter_codes":  dead_letter_codes,
        "extension_rows":     ext_rows_total,
        "spine_stats":        orch.stats.to_dict(),
        "key_map_writes":     km.persistence_stats(),
    }
